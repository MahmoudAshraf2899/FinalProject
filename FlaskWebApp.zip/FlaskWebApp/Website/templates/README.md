# Notes Web Application

#### Video Demo: https://www.youtube.com/watch?v=GA-k470V7J0

#### Description:

This Project is Web Application By Using Python & SQL & Java script and Flask .Users Can Create Accounts and Sign in to add their daily Notes and they have option to delete any of them as they want this project have alot of validations on sign-up page and login page
